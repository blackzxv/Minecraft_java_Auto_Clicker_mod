package NXxueyue.mouse.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.item.*;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

/**
 * 自动连点 + 自动放方块
 * 
 * V 键 → 开关左键连点（手持武器按住左键每2tick攻击/空挥）
 * B 键 → 开关右键放方块（手持方块按住右键每秒约16个）
 */
public class MouseClient implements ClientModInitializer {

    // 左键连点
    public static boolean attackEnabled = false;
    private static KeyBinding attackToggleKey;
    private static boolean wasAttackKeyPressed = false;
    private static int attackTickCounter = 0;

    // 右键放方块
    public static boolean placeEnabled = false;
    private static KeyBinding placeToggleKey;
    private static boolean wasPlaceKeyPressed = false;
    private static int placeTickCounter = 0;

    @Override
    public void onInitializeClient() {
        // V 键 - 左键连点
        attackToggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.mouse.attack",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_V,
            "category.mouse.main"
        ));

        // B 键 - 右键放方块
        placeToggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.mouse.place",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_B,
            "category.mouse.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(MouseClient::onTick);
    }

    private static void onTick(MinecraftClient client) {
        if (client.player == null) return;

        // ===== V 键切换：左键连点 =====
        boolean attackPressed = attackToggleKey.isPressed();
        if (attackPressed && !wasAttackKeyPressed) {
            attackEnabled = !attackEnabled;
            client.player.sendMessage(
                Text.literal(attackEnabled ? "§aAttack ON" : "§cAttack OFF"),
                true
            );
        }
        wasAttackKeyPressed = attackPressed;

        // ===== B 键切换：右键放方块 =====
        boolean placePressed = placeToggleKey.isPressed();
        if (placePressed && !wasPlaceKeyPressed) {
            placeEnabled = !placeEnabled;
            client.player.sendMessage(
                Text.literal(placeEnabled ? "§aPlace ON" : "§cPlace OFF"),
                true
            );
        }
        wasPlaceKeyPressed = placePressed;

        if (client.interactionManager == null) return;

        // ===== 左键连点逻辑 =====
        if (attackEnabled
            && isWeapon(client.player.getMainHandStack().getItem())
            && client.options.attackKey.isPressed()) {

            attackTickCounter++;
            if (attackTickCounter >= 2) {
                attackTickCounter = 0;

                if (client.crosshairTarget instanceof EntityHitResult hit) {
                    Entity target = hit.getEntity();
                    client.interactionManager.attackEntity(client.player, target);
                } else {
                    client.player.swingHand(Hand.MAIN_HAND);
                }
            }
        } else {
            attackTickCounter = 0;
        }

        // ===== 右键放方块逻辑 =====
        if (placeEnabled
            && client.player.getMainHandStack().getItem() instanceof BlockItem
            && client.options.useKey.isPressed()) {

            placeTickCounter++;
            // 随机 1 或 2 tick，概率 75%:25%，平均 1.25 tick ≈ 每秒 16 个
            int interval = Math.random() < 0.75 ? 1 : 2;
            if (placeTickCounter >= interval) {
                placeTickCounter = 0;

                if (client.crosshairTarget instanceof BlockHitResult blockHit) {
                    client.interactionManager.interactBlock(
                        client.player,
                        Hand.MAIN_HAND,
                        blockHit
                    );
                }
            }
        } else {
            placeTickCounter = 0;
        }
    }

    private static boolean isWeapon(Item item) {
        return item instanceof SwordItem
            || item instanceof AxeItem
            || item instanceof TridentItem
            || item instanceof MaceItem;
    }
}